﻿Public Class Form1

    
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim FirstG As Double
        FirstG = TextBox1.Text

        Dim SecondG As Double
        SecondG = TextBox2.Text

        Dim ThirdG As Double
        ThirdG = TextBox3.Text

        Dim FinalGrade As Double
        FinalGrade = ((FirstG + SecondG + ThirdG) / 3)

        If (FinalGrade >= 75) Then
            MessageBox.Show(" :) " & FinalGrade)

        End If
        MessageBox.Show(" :( " & FinalGrade)



    End Sub
End Class
